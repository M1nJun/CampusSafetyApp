package lawrence;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CampusSafetyApplicationTests {

	@Test
	void contextLoads() {
	}

}
