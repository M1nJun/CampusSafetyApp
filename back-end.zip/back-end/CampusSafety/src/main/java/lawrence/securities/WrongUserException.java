package lawrence.securities;

public class WrongUserException {
}
